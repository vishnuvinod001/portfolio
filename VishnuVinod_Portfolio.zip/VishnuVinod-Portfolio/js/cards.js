// ==========================================================
// CARDS — live AI visuals behind the project cards, and the
// LeetCode stats card.
//   vector  : GHOST — points in an embedding space; a query lands
//             and its nearest neighbours light up (vector search)
//   segment : research — a generated "image" split into masks;
//             one region at a time is picked out (SAM + CLIP)
//   neat    : Flappy Bird — a small population learns to fly by
//             neuroevolution, generation by generation
//   parse   : Resume Bank — a PDF's lines stream into JSON fields
//   route   : ticketing — emails get routed to departments
// Canvases render at low resolution and are scaled up by CSS,
// so they look soft (no costly CSS blur) and stay cheap.
// ==========================================================
(() => {
  'use strict';
  const RES = 3;                                             // 1 canvas pixel = 3 css pixels
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const smooth = (x, a, b) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
  const mulberry32 = (a) => () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  const hex = (h) => { h = String(h).trim().replace('#', ''); if (h.length === 3) h = h.split('').map(c => c + c).join(''); return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)]; };
  const rgba = (c, a) => 'rgba(' + (c[0] | 0) + ',' + (c[1] | 0) + ',' + (c[2] | 0) + ',' + a.toFixed(3) + ')';
  let C1 = [94, 225, 255], C2 = [139, 124, 255];
  const readTheme = () => { try { C1 = hex(cssVar('--c1')); C2 = hex(cssVar('--c3')); } catch (e) {} };
  readTheme(); document.addEventListener('themechange', readTheme);
  const still = typeof reduce !== 'undefined' && reduce;

  // shared plumbing: size to the card, run only while on screen
  function mount(card, api){
    const cv = card.querySelector('.p-viz'); if (!cv) return;
    const c = cv.getContext('2d');
    let w = 1, h = 1, raf = 0, last = 0, inView = false;
    function resize(){
      w = Math.max(1, Math.round(card.clientWidth / RES)); h = Math.max(1, Math.round(card.clientHeight / RES));
      cv.width = w; cv.height = h; api.resize && api.resize(w, h); api.draw(c, w, h);
    }
    function frame(t){
      raf = requestAnimationFrame(frame);
      if (t - last < 33) return;                             // ~30fps is plenty for a background
      const dt = Math.min(.05, (t - last) / 1000); last = t;
      api.update(dt); api.draw(c, w, h);
    }
    const run = () => { if (raf || !inView || document.hidden || still) return; last = performance.now(); raf = requestAnimationFrame(frame); };
    const halt = () => { if (raf){ cancelAnimationFrame(raf); raf = 0; } };
    resize();
    if (still){ api.update(1.4); api.update(.6); api.draw(c, w, h); }
    if ('ResizeObserver' in window) new ResizeObserver(resize).observe(card);
    if ('IntersectionObserver' in window) new IntersectionObserver(en => { inView = en[0].isIntersecting; inView ? run() : halt(); }).observe(card);
    else { inView = true; run(); }
    document.addEventListener('visibilitychange', () => { document.hidden ? halt() : run(); });
  }

  const VIZ = {
    // ---------- GHOST: vector search ----------
    vector(){
      const rng = mulberry32(77), centers = [[.1, .3], [.28, .72], [.48, .28], [.66, .72], [.86, .32], [.46, .56]], pts = [];
      centers.forEach((ctr, ci) => { for (let i = 0; i < 14; i++) pts.push({ bx: ctr[0] + (rng() - .5) * .13, by: ctr[1] + (rng() - .5) * .24, r: .008 + rng() * .03, a: rng() * 6.28, om: (.15 + rng() * .35) * (rng() < .5 ? -1 : 1), tone: ci % 2 }); });
      let W = 1, H = 1, timer = .6, queries = [];
      const pos = p => [(p.bx + Math.cos(p.a) * p.r) * W, (p.by + Math.sin(p.a) * p.r * 1.2) * H];
      return {
        resize(w, h){ W = w; H = h; },
        update(dt){
          for (const p of pts) p.a += p.om * dt;
          timer -= dt;
          if (timer <= 0){
            const ctr = centers[Math.floor(Math.random() * centers.length)], q = [(ctr[0] + (Math.random() - .5) * .14) * W, (ctr[1] + (Math.random() - .5) * .24) * H];
            const nn = pts.map((p, i) => { const pp = pos(p); return {i, d: Math.hypot(pp[0] - q[0], pp[1] - q[1])}; }).sort((a, b) => a.d - b.d).slice(0, 6).map(o => o.i);
            queries.push({x: q[0], y: q[1], t: 0, nn}); timer = 2.2 + Math.random() * 1.2;
          }
          for (const q of queries) q.t += dt;
          queries = queries.filter(q => q.t < 3.2);
        },
        draw(c, w, h){
          c.clearRect(0, 0, w, h);
          for (const p of pts){ const pp = pos(p); c.fillStyle = rgba(p.tone ? C2 : C1, .55); c.beginPath(); c.arc(pp[0], pp[1], 1.4, 0, 6.2832); c.fill(); }
          for (const q of queries){
            const show = smooth(q.t, .25, .7) * (1 - smooth(q.t, 2.2, 3.2));
            if (q.t < 1.2){ c.strokeStyle = rgba(C1, .7 * (1 - q.t / 1.2)); c.lineWidth = 1; c.beginPath(); c.arc(q.x, q.y, 3 + q.t * Math.min(w, h) * .3, 0, 6.2832); c.stroke(); }
            c.strokeStyle = rgba(C1, .8 * show); c.lineWidth = 1;
            for (const i of q.nn){ const pp = pos(pts[i]); c.beginPath(); c.moveTo(q.x, q.y); c.lineTo(pp[0], pp[1]); c.stroke(); c.fillStyle = rgba(C1, .95 * show); c.beginPath(); c.arc(pp[0], pp[1], 1.6 + 1.4 * show, 0, 6.2832); c.fill(); }
            c.fillStyle = rgba([255, 255, 255], .9 * smooth(q.t, 0, .2) * (1 - smooth(q.t, 2.2, 3.2))); c.beginPath(); c.arc(q.x, q.y, 2, 0, 6.2832); c.fill();
          }
        }
      };
    },
    // ---------- research: masks + one region selected ----------
    segment(){
      const rng = mulberry32(31), palette = [[94, 225, 255], [139, 124, 255], [58, 214, 196], [120, 150, 255], [190, 120, 255]], blobs = [];
      for (let i = 0; i < 9; i++) blobs.push({ u: ((i % 3) + .5) / 3 + (rng() - .5) * .1, v: (Math.floor(i / 3) + .5) / 3 + (rng() - .5) * .14, rx: .09 + rng() * .05, ry: .1 + rng() * .07, rot: rng() * 3, ph: rng() * 6.28, sp: .2 + rng() * .3, col: palette[i % 5], sel: 0 });
      let t = 0, pick = 0, timer = 1;
      return {
        update(dt){ t += dt; timer -= dt; if (timer <= 0){ pick = Math.floor(Math.random() * blobs.length); timer = 2.2; } blobs.forEach((b, i) => { b.sel += ((i === pick ? 1 : 0) - b.sel) * Math.min(1, dt * 3.5); }); },
        draw(c, w, h){
          c.clearRect(0, 0, w, h);
          for (const b of blobs){
            const cx = b.u * w + Math.sin(t * b.sp + b.ph) * 2, cy = b.v * h + Math.cos(t * b.sp + b.ph) * 2, rx = b.rx * w, ry = b.ry * h;
            const g = c.createRadialGradient(cx, cy, 0, cx, cy, Math.max(rx, ry)); g.addColorStop(0, rgba(b.col, .42)); g.addColorStop(1, rgba(b.col, .08));
            c.fillStyle = g; c.beginPath(); c.ellipse(cx, cy, rx, ry, b.rot, 0, 6.2832); c.fill();
            c.setLineDash([2, 2]); c.strokeStyle = 'rgba(255,255,255,.22)'; c.lineWidth = 1; c.stroke(); c.setLineDash([]);
            if (b.sel > .02){ c.fillStyle = rgba(C1, .3 * b.sel); c.fill(); c.strokeStyle = rgba(C1, .95 * b.sel); c.lineWidth = 1.2; c.stroke(); }
          }
        }
      };
    },
    // ---------- Flappy Bird learning by neuroevolution ----------
    neat(card){
      const WH = 400, BX = 80, R = 9, GAP = 124, PW = 48, SPACING = 230, SPEED = 2.3, GRAV = .38, FLAP = -6.2, POP = 14;
      const NIN = 4, NH = 4, GL = NIN * NH + NH + NH + 1;
      let scale = 1, WW = 640, birds = [], pipes = [], gen = 1, steps = 0, acc = 0;
      const label = card.querySelector('.viz-tag');
      const rnd = () => Math.random() * 2 - 1, newGenome = () => Array.from({length: GL}, rnd), mutate = (g, amt) => g.map(w => Math.random() < .35 ? w + rnd() * amt : w);
      function think(g, inp){ let out = g[NIN * NH + NH + NH]; for (let hh = 0; hh < NH; hh++){ let sum = g[NIN * NH + hh]; for (let i = 0; i < NIN; i++) sum += g[hh * NIN + i] * inp[i]; out += g[NIN * NH + NH + hh] * Math.tanh(sum); } return out > 0; }
      function reset(gs){ birds = gs.map(g => ({g, y: WH / 2 + rnd() * 40, vy: 0, alive: true, score: 0})); pipes = []; steps = 0; }
      function evolve(){ birds.sort((a, b) => b.score - a.score); const top = birds.slice(0, 3).map(b => b.g), next = [top[0]]; while (next.length < POP) next.push(mutate(top[Math.floor(Math.random() * top.length)], next.length < 5 ? .35 : .9)); gen++; reset(next); }
      const nextPipe = () => { for (const p of pipes) if (p.x + PW > BX - R) return p; return null; };
      function step(){
        steps++; const lp = pipes[pipes.length - 1];
        if (!lp || lp.x < WW - SPACING) pipes.push({x: WW + 20, gy: 100 + Math.random() * (WH - 200)});
        for (const p of pipes) p.x -= SPEED; if (pipes[0].x < -PW - 10) pipes.shift();
        const np = nextPipe(); let alive = 0;
        for (const b of birds){
          if (!b.alive) continue;
          const inp = [b.y / WH, b.vy / 10, np ? (np.gy - b.y) / WH : 0, np ? (np.x - BX) / WW : 1];
          if (think(b.g, inp)) b.vy = FLAP; b.vy += GRAV; b.y += b.vy; b.score++;
          if (b.y < R || b.y > WH - R) b.alive = false;
          else if (np && BX + R > np.x && BX - R < np.x + PW && Math.abs(b.y - np.gy) > GAP / 2 - R) b.alive = false;
          if (b.alive) alive++;
        }
        if (!alive || steps > 2600) evolve();
      }
      reset(Array.from({length: POP}, newGenome));
      for (let i = 0; i < 20000 && gen < 14; i++) step();      // warm start: first generations happen off-screen
      return {
        resize(w, h){ scale = h / WH; WW = w / scale; },
        update(dt){ acc += dt; while (acc >= 1 / 60){ step(); acc -= 1 / 60; } },
        draw(c, w, h){
          c.clearRect(0, 0, w, h); c.save(); c.scale(scale, scale);
          c.fillStyle = rgba(C2, .55);
          for (const p of pipes){ const top = p.gy - GAP / 2, bot = p.gy + GAP / 2; c.fillRect(p.x, 0, PW, top - 14); c.fillRect(p.x - 4, top - 14, PW + 8, 14); c.fillRect(p.x, bot + 14, PW, WH - bot - 14); c.fillRect(p.x - 4, bot, PW + 8, 14); }
          c.fillStyle = rgba(C1, .65);
          for (const b of birds){ if (!b.alive) continue; c.beginPath(); c.arc(BX, b.y, R, 0, Math.PI * 2); c.fill(); }
          c.restore();
          if (label){ const tx = `live simulation · generation ${gen}`; if (label.textContent !== tx) label.textContent = tx; }
        }
      };
    },
    // ---------- Resume Bank: lines of a PDF become JSON fields ----------
    parse(){
      let t = 0; const rows = Array.from({length: 11}, (_, i) => ({w: .25 + Math.random() * .5, y: .12 + i * .072}));
      return {
        update(dt){ t += dt; },
        draw(c, w, h){
          c.clearRect(0, 0, w, h);
          const pw = w * .34, px = w * .06, py = h * .08, ph = h * .84;
          c.fillStyle = 'rgba(230,235,255,.10)'; c.fillRect(px, py, pw, ph);
          const scan = (t * .35) % 1;
          rows.forEach((r, i) => {
            const y = py + ph * r.y, hit = Math.abs(r.y - scan) < .05;
            c.fillStyle = hit ? rgba(C1, .9) : 'rgba(200,210,240,.35)'; c.fillRect(px + 4, y, (pw - 8) * r.w, 2);
          });
          c.fillStyle = rgba(C1, .35); c.fillRect(px, py + ph * scan - 1, pw, 2);
          // fields on the right fill in one by one
          const fx = w * .55, fw = w * .38, n = 4, cyc = (t * .5) % (n + 1.5);
          for (let i = 0; i < n; i++){
            const y = h * (.16 + i * .19), on = smooth(cyc, i, i + .6);
            c.strokeStyle = rgba(C2, .5); c.lineWidth = 1; c.strokeRect(fx, y, fw, h * .12);
            c.fillStyle = rgba(C1, .75 * on); c.fillRect(fx + 2, y + 2, (fw - 4) * on * (.55 + .4 * ((i * 37) % 10) / 10), h * .12 - 4);
          }
          // packets flying from page to fields
          for (let k = 0; k < 3; k++){ const u = ((t * .6) + k / 3) % 1, x = px + pw + (fx - px - pw) * u, y = h * (.3 + .4 * Math.sin(u * Math.PI + k)); c.fillStyle = rgba([255, 255, 255], .8 * Math.sin(u * Math.PI)); c.fillRect(x, y, 2, 2); }
        }
      };
    },
    // ---------- ticketing: emails routed to departments ----------
    route(){
      let t = 0; const mails = [];
      const depts = [.2, .4, .6, .8];
      return {
        update(dt){ t += dt; if (Math.random() < dt * 1.4) mails.push({u: 0, d: Math.floor(Math.random() * 4)}); mails.forEach(m => m.u += dt * .45); for (let i = mails.length - 1; i >= 0; i--) if (mails[i].u > 1) mails.splice(i, 1); },
        draw(c, w, h){
          c.clearRect(0, 0, w, h);
          const hx = w * .12, hy = h * .5, rx = w * .5, dx = w * .86;
          c.strokeStyle = rgba(C2, .35); c.lineWidth = 1;
          depts.forEach(v => { c.beginPath(); c.moveTo(rx, hy); c.quadraticCurveTo(w * .7, h * v, dx, h * v); c.stroke(); c.fillStyle = rgba(C2, .6); c.fillRect(dx, h * v - 3, 7, 6); });
          c.beginPath(); c.moveTo(hx, hy); c.lineTo(rx, hy); c.stroke();
          c.fillStyle = rgba(C1, .5 + .3 * Math.sin(t * 3)); c.beginPath(); c.arc(rx, hy, 4, 0, 6.2832); c.fill();
          for (const m of mails){
            let x, y;
            if (m.u < .5){ const k = m.u / .5; x = hx + (rx - hx) * k; y = hy; }
            else { const k = (m.u - .5) / .5, v = depts[m.d]; x = (1 - k) * (1 - k) * rx + 2 * (1 - k) * k * w * .7 + k * k * dx; y = (1 - k) * (1 - k) * hy + 2 * (1 - k) * k * h * v + k * k * h * v; }
            c.fillStyle = rgba([255, 255, 255], .85); c.fillRect(x - 3, y - 2, 6, 4);
          }
        }
      };
    }
  };

  document.querySelectorAll('.project.has-viz').forEach(card => {
    const make = VIZ[card.dataset.viz]; if (make) mount(card, make(card));
  });

  // ---------- LeetCode live stats (served by /api/leetcode on Vercel) ----------
  (() => {
    const body = document.getElementById('lc-body'), note = document.getElementById('lc-note');
    if (!body) return;
    const el = (tag, cls, txt) => { const n = document.createElement(tag); if (cls) n.className = cls; if (txt != null) n.textContent = txt; return n; };
    const heat = (cal) => {
      const weeks = window.innerWidth < 640 ? 27 : 53, DAY = 86400000;
      const now = new Date(), today = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
      const start = today - (new Date(today).getUTCDay() + (weeks - 1) * 7) * DAY;
      const by = {};
      Object.keys(cal).forEach((k) => { const t = Number(k) * 1000; if (!isNaN(t)) by[Math.floor(t / DAY) * DAY] = (by[Math.floor(t / DAY) * DAY] || 0) + Number(cal[k]); });
      const grid = el('div', 'lc-grid'); let sum = 0;
      for (let i = 0; i < weeks * 7; i++){
        const t = start + i * DAY, c = by[t] || 0, cell = el('i');
        if (t > today) cell.className = 'fut';
        else {
          sum += c;
          if (c) cell.className = c >= 7 ? 'l4' : c >= 4 ? 'l3' : c >= 2 ? 'l2' : 'l1';
          cell.title = c + ' submission' + (c === 1 ? '' : 's') + ' on ' + new Date(t).toLocaleDateString(undefined, {month: 'short', day: 'numeric', year: 'numeric', timeZone: 'UTC'});
        }
        grid.append(cell);
      }
      const wrap = el('div', 'lc-heat'), head = el('div', 'lc-heat-head');
      head.append(el('b', '', String(sum)), ' submissions in the past ' + (weeks > 40 ? 'year' : '6 months'));
      wrap.append(head, grid); body.append(wrap);
    };
    const render = (d) => {
      body.textContent = '';
      const tot = el('div', 'lc-total'); tot.append(el('b', '', String(d.total)), el('span', '', 'problems solved'));
      const bars = el('div', 'lc-bars'), max = Math.max(1, d.easy, d.medium, d.hard);
      [['Easy', d.easy, '#5ee1ff'], ['Medium', d.medium, '#ffb84d'], ['Hard', d.hard, '#ff6b81']].forEach(([n, v, c]) => {
        const row = el('div', 'lc-row'), bar = el('i'), fill = el('u');
        fill.style.background = c; fill.style.width = '0%'; bar.append(fill);
        row.append(el('span', '', n), bar, el('em', '', String(v))); bars.append(row);
        requestAnimationFrame(() => requestAnimationFrame(() => { fill.style.width = Math.max(4, v / max * 100) + '%'; }));
      });
      body.append(tot, bars);
      const meta = el('div', 'lc-meta');
      if (d.streak != null){ const s = el('span'); s.append('Current streak ', el('b', '', d.streak + ' days')); meta.append(s); }
      if (d.activeDays != null){ const s = el('span'); s.append('Active days this year ', el('b', '', String(d.activeDays))); meta.append(s); }
      if (meta.childNodes.length) body.append(meta);
      if (d.calendar && typeof d.calendar === 'object') heat(d.calendar);
    };
    const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), 6000);
    fetch('/api/leetcode', {signal: ctl.signal}).then(r => (r.ok ? r.json() : Promise.reject())).then(d => {
      if (d && typeof d.total === 'number') render(d); else throw 0;
    }).catch(() => { if (note) note.textContent = 'Live stats are unavailable right now. See my profile for the latest.'; }).finally(() => clearTimeout(to));
  })();
})();
